const startDate = new Date('2026-04-26');
const today = new Date();
const diffTime = today.getTime() - startDate.getTime();
const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
document.getElementById('daysCount').textContent = diffDays;

document.getElementById('playBtn').addEventListener('click', function(e) {
    e.preventDefault();
    alert('Игра в разработке. Релиз 26 октября 2026. Жди!');
});

document.getElementById('launcherBtn').addEventListener('click', function(e) {
    e.preventDefault();
    alert('Лаунчер скоро будет доступен. Следи за обновлениями!');
});